


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Manage Grades</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style/system.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.2/xlsx.full.min.js" integrity="sha512-qilAGdDSZ5c0sTjizcSCffmIb8D2rHttMYGUxtI3OFn8lB29BlU2tEUcPesHHLQ2t0Y5TInglWKY6V3GoSK0IA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>  


</head>

<body>

<div class="modal fade" id="modalAddFileGrade" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="labelFormodalAddFileGrade">Add Grade File</h1>
        <button type="button" class="btn-close close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <label for="course">Course</label>
        <input type="text" id="course" class="form-control" disabled>

        <label for="subject">Subject Code</label>
        <input type="text" id="subject" class="form-control" disabled>

        <br>
        <label for="ExcelFileInput">Please Attach the downloaded excel here. <i id="filename"></i> </label>
        <input type="file" name="" id="ExcelFileInput" accept=".xlsx, .xls">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary close" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-info" id="updateGrades">Update</button>
        <button type="button" class="btn btn-primary" id="saveGrades">Save</button>

      </div>
    </div>
  </div>
</div>


    <div class="container-fluid row" id="whole-container">

        <div class="col-2" id="sidebar">

            <?php include '/xampp/htdocs/capstone/config/sidebar.php'    ?>


        </div>

        <div class="col-10 " id="content">
        <div class="container-fluid" id="samp-header">
                <hr>
            </div>

          <div class="row" id="box-wrapper">
            <div class="col-12 dbox shadow p-4">
            <p class="h5">Approved Files Table</p>

            <table class="display text-center mt-5 w-100" id="approvedTable">
            <thead>
                <tr>
                    <th>GFID</th>
                    <th>Teacher</th>
                    <th>Subject</th>
                    <th>Course</th>
                    <th>Year Level</th>
                    <th>Filename</th>
                    <th></th>
                </tr>


            </thead>

            <tbody>

            </tbody>




            </table>

            </div>
           
          </div>


        </div>

    </div>




    <script src="./js/manage.grades.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>



</html>