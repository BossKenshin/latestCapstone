<?php
include '/xampp/htdocs/capstone/dbconnect.php';

$dept = str_replace( "'" ,"''",htmlspecialchars($_GET['dept']));


$teacher = "SELECT `teacher_firstname` as fn,`teacher_lastname` as ln,`teacher_middlename` as mn,`teacher_username` as username,`teacher_password` as password FROM teacher 
INNER JOIN department ON department.dept_id = teacher.dept_id WHERE teacher.dept_id = '$dept';";
$res = mysqli_query($conn,$teacher);

$teacher_array = array();

while ($row = mysqli_fetch_assoc($res)) {
    $teacher_array[] = $row;
}


 echo json_encode($teacher_array);

?>