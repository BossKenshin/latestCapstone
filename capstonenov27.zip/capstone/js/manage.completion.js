setCompletionGradeTable();


function setCompletionGradeTable() {

    $(document).ready(function () {

        //var year = document.getElementById("StudentYear").value;
        var deptid = 5;


        $.ajax({
            url: "./sql_functions/fetch.completion.grades.php",
            success: function (data) {


                var pendingData = JSON.parse(data);


                $('#completionGradesTable').DataTable({
                    data: pendingData,
                    columns: [
                        { data: 'cid' },
                        { data: 'teacher_fullname' },
                        { data: 'subject_code' },
                        { data: 'subject_name' },
                        { data: 'student_name' },
                        { data: 'student_sid' },
                        { data: 'grade' },
                        {
                            data: 'null',
                            className: "view btn-outline-dark",
                            defaultContent: '<i class="bi bi-plus-circle-fill"></i>',
                            orderable: false
                        }
                    ]

                });
            }
        })


    });
}




$('#completionGradesTable').on('click', 'td.view', function (e) {

    var currentRow = $(this).closest("tr");

    var col1 = currentRow.find("td:eq(0)").text(); // get current row 1st TD valu
    var col2 = currentRow.find("td:eq(1)").text(); // get current row 2nd TD
    var col3 = currentRow.find("td:eq(2)").text(); // get current row 3rd TD
    var col4 = currentRow.find("td:eq(3)").text(); // get current row 4th TD
    var col5 = currentRow.find("td:eq(4)").text(); // get current row 5th TD
    var col6 = currentRow.find("td:eq(5)").text(); // get current row 6th TD
    var col7 = currentRow.find("td:eq(6)").text(); // get current row 6th TD

    console.log(col3, col6, col7);

    $.ajax({
        url: "./sql_functions/add.completion.grades.php",
        dataType: "script",
        data: {
                'cid'   : col1,
                'sub_code'  : col3,
                'st_id' : col6,
                'grade' : col7
        },
        success: function (data2) {

            if(data2 == 0){
                Swal.fire({
                    icon: 'success',
                    title: 'Added Successfully',
                    text: 'Grade has now been added to database',

                })

                $("#completionGradesTable").DataTable().clear().destroy();
                setCompletionGradeTable();
            }
            else{
                Swal.fire({
                    icon: 'error',
                    title: 'Unsuccessful',
                    text: 'Grade could not be added to database',

                })
            }
            
            }

        })

    


});
