$("#btn-logout-dept").click(function(){

    document.cookie = "dept_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    window.location.replace = "./index.html";
})

$("#btn-logout-admin").click(function(){

   document.cookie = "admin_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
   window.location.replace = "./index.html";

})
$("#btn-logout-teacher").click(function(){

    document.cookie = "staff_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    window.location.replace = "./index.html";

})
$("#btn-logout-vice").click(function(){

   // document.cookie = "vp_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    window.location.replace = "./index.html";

})


$("#btn-logout-student").click(function(){
    //document.cookie = "st_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    
    localStorage.clear();
    window.location.reload();

})