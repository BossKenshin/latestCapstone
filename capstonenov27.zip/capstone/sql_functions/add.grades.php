<?php
include '/xampp/htdocs/capstone/dbconnect.php';



$st_schoolid = str_replace("'", "''", htmlspecialchars($_GET['st_schoolid']));
$finalgrade = str_replace("'", "''", htmlspecialchars($_GET['grade']));
$sub_code = str_replace("'", "''", htmlspecialchars($_GET['subject_code']));

$sql_get_duplicate ="SELECT '$st_schoolid','$sub_code','$finalgrade' FROM grades 
WHERE st_schoolid='$st_schoolid' AND subject_code='$sub_code' AND grade='$finalgrade";

$result = mysqli_query($conn,$sql_get_duplicate);

if(mysqli_num_rows($result) == 0){

    $insert_grade = "INSERT IGNORE INTO `grades`(`st_schoolid`, `subject_code`, `grade`) 
                    VALUES ('$st_schoolid','$sub_code','$finalgrade')";

$res1 = mysqli_query($conn, $insert_grade);


if ($res1) {
    echo 0;
} else {
    echo 1;
}

}
else{
  
    $update_grade = "UPDATE grades SET st_schoolid='$st_schoolid',subject_code='$sub_code',grade='$finalgrade'
     WHERE st__schoolid='$st_schoolid' AND sub_code='$sub_code' AND grade='$finalgrade';";

$res1 = mysqli_query($conn, $update_grade);


if ($res1) {

echo 0;
} 
else {

echo 1;
}

}




?>
