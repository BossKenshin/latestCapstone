<?php
include '/xampp/htdocs/capstone/dbconnect.php';



$st_schoolid = str_replace("'", "''", htmlspecialchars($_GET['st_schoolid']));
$finalgrade = str_replace("'", "''", htmlspecialchars($_GET['grade']));
$sub_code = str_replace("'", "''", htmlspecialchars($_GET['subject_code']));



$update_grade = "UPDATE grades SET  grade = '$finalgrade' WHERE subject_code = '$sub_code' AND st_schoolid = '$st_schoolid'";

$res1 = mysqli_query($conn, $update_grade);


if ($res1) {
    echo 0;
} else {
    echo 1;
}
