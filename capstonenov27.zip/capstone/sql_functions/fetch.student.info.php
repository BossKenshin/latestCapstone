<?php
include '/xampp/htdocs/capstone/dbconnect.php';

$schoolid = $_GET['st_id'];

$student = "SELECT `student_id` as id, `student_schoolid` as sid, CONCAT( `student_firstname`,' ',`student_lastname`,' ',`student_middlename`) as name, department.dept_abbreviation as department , course.course_abbreviation as course, year_level as year FROM `student`
INNER JOIN department ON student.student_deptID = department.dept_id
INNER JOIN course ON student.student_courseID = course.course_id 
WHERE student_schoolid = '$schoolid';";
$res = mysqli_query($conn,$student);

$student_arr = array();

while ($row = mysqli_fetch_assoc($res)) {
    $student_arr[] = $row;
}


 echo json_encode($student_arr);

?>