
<div class="container-fluid row justify-content-between mt-5 bg-light boxes-div" id="box-content">

<div class="col-3">COL1</div>
<div class="col-3">COL2</div>
<div class="col-3">COL3</div>


</div>

<div class="container-fluid row justify-content-between mt-3 bg-light boxes-div" id="sec-box-content">

<div class="col-3">COL1</div>
<div class="col-3">COL2</div>
<div class="col-3">COL3</div>


</div>

<div class="container-fluid row mt-5 rect-div" id="rect-content">Rectangle 1</div>
<div class="container-fluid row mt-3 rect-div" id="sec-rect-content">Rectangle 2</div>
