<?php
include '/xampp/htdocs/capstone/dbconnect.php';



$st_schoolid = str_replace("'", "''", htmlspecialchars($_GET['st_schoolid']));
$finalgrade = str_replace("'", "''", htmlspecialchars($_GET['grade']));
$sub_code = str_replace("'", "''", htmlspecialchars($_GET['subject_code']));



$insert_grade = "INSERT IGNORE INTO `grades`(`st_schoolid`, `subject_code`, `grade`) 
                    VALUES ('$st_schoolid','$sub_code','$finalgrade')";

$res1 = mysqli_query($conn, $insert_grade);


if ($res1) {
    echo 0;
} else {
    echo 1;
}
