<?php

include '/xampp/htdocs/capstone/dbconnect.php';

$course = str_replace( "'" ,"''",htmlspecialchars($_GET['course']));


$student = "SELECT  `student_schoolid` as school_id, CONCAT(`student_firstname`,' ',`student_middlename`,' ',`student_lastname`) AS fullname
FROM student 	
INNER JOIN course ON student.student_courseID = course.course_id
WHERE course.course_id = '$course';";

$res = mysqli_query($conn,$student);

$student_arr = array();

while ($row = mysqli_fetch_assoc($res)) {
    $student_arr[] = $row;
}


 echo json_encode($student_arr);

?>