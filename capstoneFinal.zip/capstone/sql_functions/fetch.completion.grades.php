<?php

include '/xampp/htdocs/capstone/dbconnect.php';


$sql_fetch_completion = "SELECT cid, CONCAT(teacher.teacher_firstname,' ', teacher.teacher_middlename,' ', teacher.teacher_lastname) as teacher_fullname, subject.subject_code, subject.subject_name, CONCAT(student.student_firstname,' ', student.student_middlename,' ', student.student_lastname) as student_name, completion_grade.student_schoolid  as student_sid ,completion_grade.grade from completion_grade
INNER JOIN teacher ON completion_grade.teacherid = teacher.teacher_id
INNER JOIN subject ON completion_grade.subjectid = subject.subject_id
INNER JOIN student ON completion_grade.student_schoolid = student.student_schoolid";





$res = mysqli_query($conn,$sql_fetch_completion);

$files_array = array();

while ($row = mysqli_fetch_assoc($res)) {
    $files_array[] = $row;
}


 echo json_encode($files_array);










?>