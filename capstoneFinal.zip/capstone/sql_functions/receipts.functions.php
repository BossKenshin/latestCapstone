<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$type = $_GET['typeOfFuntion'];


if($type == 'approve'){

    $id = $_GET['id'];
    
    $update = "UPDATE admin_receipt SET print_status = 'approve' WHERE arid = '$id'";

    $result = mysqli_query($conn, $update);

    if($result){
        echo 0;
    }
    else{
        echo 1;
    }

}
else if($type == 'fetch'){


    $sql = "SELECT `arid` as id,`receipt`,`st_id`, CONCAT(student.student_firstname, ' ', student.student_middlename,' ',student.student_lastname) as st_name,`receipt_pic`,`dateSent` from admin_receipt
    INNER JOIN student ON admin_receipt.st_id = student.student_schoolid
    WHERE print_status = 'pending';";


    $result = mysqli_query($conn,$sql);

    $res_arr = array();

    while($row = mysqli_fetch_assoc($result)){
        $res_arr[] = $row;
    }

    echo json_encode($res_arr);



}
else{

    $id = $_GET['id'];
    
    $update = "UPDATE admin_receipt SET print_status = 'rejected' WHERE arid = '$id'";

    $result = mysqli_query($conn, $update);

    if($result){
        echo 0;
    }
    else{
        echo 1;
    }

}



?>