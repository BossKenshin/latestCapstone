<?php
include '/xampp/htdocs/capstone/dbconnect.php';

$text = htmlspecialchars($_GET['concernText']);
$teacher = htmlspecialchars($_GET['te']);
$st = htmlspecialchars($_GET['st']);


// $teacherid = str_replace( "'" ,"''",htmlspecialchars($_GET['sem']));



$insertFile = "INSERT INTO `concern`(`textValue`, `teacher_name`, `student_name`) 
VALUES ('$text','$teacher', '$st')";

$res = mysqli_query($conn, $insertFile);

if($res){

echo 0;
}
else{
echo 1;
}



?>