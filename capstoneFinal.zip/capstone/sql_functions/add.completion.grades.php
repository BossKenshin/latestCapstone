<?php

include '/xampp/htdocs/capstone/dbconnect.php';

$code = $_GET['sub_code'];
$sid = $_GET['st_id'];
$grade = $_GET['grade'];

$sql_completion;

$check_grade = "SELECT * FROM grades WHERE st_schoolid = '$sid' AND subject_code ='$code'";

$res = mysqli_query($conn,$check_grade);

if(mysqli_num_rows($res) == 0){

    $sql_completion = "INSERT INTO grades (st_schoolid, subject_code,grade) VALUES ('$sid', '$code', '$grade')";


}
else{
    $sql_completion = "UPDATE grades SET grade = '$grade' WHERE st_schoolid = '$sid' AND subject_code = '$code'";
}


$res2 = mysqli_query($conn,$sql_completion);



if ($res2) {

    $cid = $_GET['cid'];
    $sql_delete = "DELETE FROM completion_grade WHERE cid = '$cid'";

    $res3 = mysqli_query($conn,$sql_delete);

    if($res3){
        echo 0;
    }

}
else{
    echo 1;

}










?>