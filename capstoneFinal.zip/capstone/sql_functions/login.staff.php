<?php
include '/xampp/htdocs/capstone/dbconnect.php';

$user = $_GET['user'];
$pass = $_GET['pass'];

$sql_search = "SELECT  `admin_id` as id,`admin_type` as type from admin
 where `admin_username` = '$user' AND `admin_password` = '$pass';";

$acc_arr = array();

$res1 = mysqli_query($conn, $sql_search);

$num_row = mysqli_num_rows($res1);

if($num_row != 0){

    while($row1 = mysqli_fetch_assoc($res1)){

        $acc_arr [] = $row1;
    }
}
else{


$sql_search_dept = "SELECT  `dept_id` as id from department 
where `dept_username` = '$user' AND `dept_password` = '$pass';";


$res2 = mysqli_query($conn, $sql_search_dept);

$num_row = mysqli_num_rows($res2);

if($num_row != 0){

$row2 = mysqli_fetch_assoc($res2);

$acc_arr = array(
    array(
            "id" => $row2['id'],
            "type" => "Department"
    )
            );
        }
        else{



$sql_search_teacher = "SELECT  `teacher_id` as id, CONCAT(teacher_firstname,' ',teacher_middlename,' ',teacher_lastname) as teach_name from teacher 
where `teacher_username` = '$user' AND `teacher_password` = '$pass';";


$res3 = mysqli_query($conn, $sql_search_teacher);

$num_row = mysqli_num_rows($res3);

if($num_row != 0){

$row3 = mysqli_fetch_assoc($res3);

$acc_arr = array(
    array(
            "id" => $row3['id'],
            "teach" => $row3['teach_name'],
            "type" => "Teacher"
    )
            );
        }





        


        }


}




// $row2 = mysqli_fetch_assoc($res2);




 echo json_encode($acc_arr);

?>