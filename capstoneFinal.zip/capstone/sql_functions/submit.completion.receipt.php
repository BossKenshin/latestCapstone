<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$file_size = $_FILES['file']['size'];
$file_tmp = $_FILES['file']['tmp_name'];
$file_type = $_FILES['file']['type'];



$file_name =  $_FILES['file']['name'];
$new_file_name = str_replace(" ", "",$file_name);




$st_id = str_replace( "'" ,"''",htmlspecialchars($_POST['st_id']));
$sub = $_POST['sub'];
$teacher = $_POST['teacher'];
// $teacherid = str_replace( "'" ,"''",htmlspecialchars($_GET['sem']));



$insertFile = "INSERT INTO `completion_receipt`(`receiptPic`, `subject`, `st_id`, `teacher_name`) 
VALUES ('$new_file_name','$sub','$st_id','$teacher')";

$res = mysqli_query($conn, $insertFile);

if($res){

move_uploaded_file($file_tmp,"C:/xampp/htdocs/capstone/completionreceipt/".$new_file_name);
echo 0;
}
else{
echo 1;
}



?>