<div class="container-fluid" style="min-height: 100vh; max-height: fit-content; padding-bottom: 10px;">

    <p class="h4 p-3 text-light text-center" id="demo">CRMC OGIS</p>

    <div class="list-group" style="font-size: 14px;">

        <p class="h6 text-light text-center">VICE-PRESIDENT DASHBOARD</p>
        
        <hr>
        <br>
        <a type="button" class="list-group-item list-group-item-action sidebar-btn" href="vp.dashboard.php"><i class="bi bi-file-earmark-spreadsheet"></i>Pending Files</a>
        <!-- <a type="button" class="list-group-item list-group-item-action sidebar-btn" href="manage.teacher.php"><i class="bi bi-people-fill"></i> Issues</a> -->
        <br>
        <hr>
        <br>
        <button type="button" class="list-group-item list-group-item-action sidebar-btn" id="btn-logout-vice"><i class="bi bi-box-arrow-right"></i> Log Out</button>

    </div>



</div>