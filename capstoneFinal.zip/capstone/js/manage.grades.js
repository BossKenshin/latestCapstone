var aid = localStorage.getItem('admin_id');

if(aid ==  null){
  window.location.replace("./index.html");

}
setApprovedTable();
setSavedGradeFilesTable();

function setApprovedTable() {

    $(document).ready(function () {

        //var year = document.getElementById("StudentYear").value;
        var deptid = 5;


        $.ajax({
            url: "./sql_functions/fetch.gradefiles.php",
            success: function (data) {


                var pendingData = JSON.parse(data);


                $('#approvedTable').DataTable({
                    data: pendingData,
                    columns: [
                        { data: 'gfid' },
                        { data: 'teacher_fullname' },
                        { data: 'subject_code' },
                        { data: 'course_abbreviation' },
                        { data: 'year_level' },
                        { data: 'filename' },
                        {
                            data: 'null',
                            className: "view btn-outline-dark",
                            defaultContent: '<i class="bi bi-plus-circle-fill"></i>',
                            orderable: false
                        }
                    ]

                });
            }
        })


    });
}



function setSavedGradeFilesTable() {

  $(document).ready(function () {

      //var year = document.getElementById("StudentYear").value;
      var deptid = 5;


      $.ajax({
          url: "./sql_functions/fetch.saved.gradefiles.php",
          success: function (data) {


              var pendingData = JSON.parse(data);


              $('#savedGradeFilesTable').DataTable({
                  data: pendingData,
                  columns: [
                      { data: 'gfid' },
                      { data: 'teacher_fullname' },
                      { data: 'subject_code' },
                      { data: 'course_abbreviation' },
                      { data: 'year_level' },
                      { data: 'filename' }
                  ]

              });
          }
      })


  });
}


$("#approvedTable").on("click", "td.view", function (e) {

    var currentRow = $(this).closest("tr");
    var col1 = currentRow.find("td:eq(0)").text(); // get current row 1st TD value
    var col2 = currentRow.find("td:eq(1)").text(); // get current row 2nd TD
    var col3 = currentRow.find("td:eq(2)").text(); // get current row 3rd TD
    var col4 = currentRow.find("td:eq(3)").text(); // get current row 4th TD
    var col5 = currentRow.find("td:eq(4)").text(); // get current row 5th TD
    var col6 = currentRow.find("td:eq(5)").text(); // get current row 6th TD

    


                        var filename = col6;
                        download(filename);

                        $("#modalAddFileGrade").modal("show");
                        document.getElementById("filename").innerHTML = "Filename: " + col6;
                        document.getElementById("subject").value = col3;
                        document.getElementById("course").value = col4;
                        document.getElementById("gfid").value =col1;



})

       function download(filename){

        var element = document.createElement('a');
        element.setAttribute('href','./superFiles/'+filename);
       element.setAttribute('download', filename);
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);

       }


       

let selectedFile;
var DBstudentObject;
var rowStudentList;

document.getElementById("ExcelFileInput").addEventListener("change", (event) => {
  selectedFile = event.target.files[0];
});

document.getElementById("saveGrades").addEventListener("click", () => {
    //  let rowObject;
    var dept = $("#course").val();
    var subject = $("#subject").val();
  
    if (selectedFile && dept != "" && dept != 0 && course != 0 && course != "") {
      let fileReader = new FileReader();
      fileReader.readAsBinaryString(selectedFile);
      fileReader.onload = (event) => {
        let data = event.target.result;
        let workbook = XLSX.read(data, { type: "binary" });
        workbook.SheetNames.forEach((sheet) => {
          rowStudentList = XLSX.utils.sheet_to_row_object_array(
            workbook.Sheets[sheet]
          );
        });
  
        var regExp = /[a-zA-Z]/;
        var len = rowStudentList.length;
        var _hasrun = false;
  
  
        for (var i = 0; i < rowStudentList.length; i++) {
          if (rowStudentList[i].hasOwnProperty("School ID") && rowStudentList[i].hasOwnProperty("Grade")) {
            if (!regExp.test(rowStudentList[i]['School ID'])) {

                console.log(rowStudentList[i]['School ID'] +' ' + rowStudentList[i]['Grade'] + ' ' + subject)
              $.ajax({
                url: "./sql_functions/add.grades.php",
                dataType: "script",
                type: "GET",
                data: {
                    st_schoolid: rowStudentList[i]['School ID'],
                    grade: rowStudentList[i]['Grade'],
                    subject_code: subject
                }
              }).done(function() {
  
                  if(i = len){
                     
                      if(_hasrun === false){

                          $("#approvedTable").DataTable().clear().destroy();
                          setApprovedTable();

                          $("#savedGradeFilesTable").DataTable().clear().destroy();
                          setSavedGradeFilesTable();

                           _hasrun = true;
                           Swal.fire({
                            icon: "success",
                            title: "Saved Successfully",
                            text: "Grades are now in database",
                          });
                          let gfile = document.getElementById("gfid").value;
                          setFileApproved(gfile)
                      }
                  }
                });
  
            } 
          } else {
            Swal.fire({
              icon: "Error",
              title: "Oops...",
              text: "You have selected a wrong file",
            });
          }
        }

        document.querySelector("#ExcelFileInput").value = "";
        $("#course").empty();
        $("#subject").empty();
  
  
        $("#modalAddFileGrade").modal("hide");
  
       
      };
    } else {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "Please fill in the missing details!!",
      });
    }
  });


  
document.getElementById("updateGrades").addEventListener("click", () => {
  //  let rowObject;
  var dept = $("#course").val();
  var subject = $("#subject").val();

  if (selectedFile && dept != "" && dept != 0 && course != 0 && course != "") {
    let fileReader = new FileReader();
    fileReader.readAsBinaryString(selectedFile);
    fileReader.onload = (event) => {
      let data = event.target.result;
      let workbook = XLSX.read(data, { type: "binary" });
      workbook.SheetNames.forEach((sheet) => {
        rowStudentList = XLSX.utils.sheet_to_row_object_array(
          workbook.Sheets[sheet]
        );
      });

      var regExp = /[a-zA-Z]/;
      var len = rowStudentList.length;
      var _hasrun = false;


      for (var i = 0; i < rowStudentList.length; i++) {
        if (rowStudentList[i].hasOwnProperty("School ID") && rowStudentList[i].hasOwnProperty("Grade")) {
          if (!regExp.test(rowStudentList[i]['School ID'])) {


            $.ajax({
              url: "./sql_functions/update.grades.php",
              dataType: "script",
              type: "GET",
              data: {
                    st_schoolid: rowStudentList[i]['School ID'],
                    grade: rowStudentList[i]['Grade'],
                    subject_code: subject
              }
            }).done(function() {

                if(i = len){
                   
                    if(_hasrun === false){
                      $("#approvedTable").DataTable().clear().destroy();
                      setApprovedTable();
                      $("#savedGradeFilesTable").DataTable().clear().destroy();
                      setSavedGradeFilesTable();

                       _hasrun = true;
                         Swal.fire({
                          icon: "success",
                          title: "Saved Successfully",
                          text: "Grades are now in database",
                        });

                        let gfile = document.getElementById("gfid").value;
                        setFileApproved(gfile)
                    }
                }
              });

          } 
        } else {
          Swal.fire({
            icon: "Error",
            title: "Oops...",
            text: "You have selected a wrong file",
          });
        }
      }

      document.querySelector("#ExcelFileInput").value = "";
      $("#course").empty();
      $("#subject").empty();


      $("#modalAddFileGrade").modal("hide");

     
    };
  } else {
    Swal.fire({
      icon: "error",
      title: "Oops...",
      text: "Please fill in the missing details!!",
    });
  }
});


function setFileApproved(gfid){

  $.ajax({
    url: "./sql_functions/update.gradefiles.php",
    dataType: "script",
    type: "GET",
    data: {
        id: gfid
          }
  })

}
  

