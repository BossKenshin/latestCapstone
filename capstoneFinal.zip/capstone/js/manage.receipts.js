

setPendingTable();

function setPendingTable() {

    $(document).ready(function () {

        //var year = document.getElementById("StudentYear").value;
       


        $.ajax({
            url: "./sql_functions/receipts.functions.php",
            data:
            {
                typeOfFuntion: 'fetch'

            },
            success: function (data) {

                var pendingData = JSON.parse(data);

                $('#receiptTable').DataTable({
                    data: pendingData,
                    columns: [
                        { data: 'id' },
                        { data: 'st_id'},
                        { data: 'st_name'},
                        { data: 'receipt'},
                        { data: 'receipt_pic' },
                        { data: 'dateSent'},
                        {
                            data: 'null',
                            className: "view btn-outline-dark",
                            defaultContent: '<i class="bi bi-file-earmark-arrow-down"></i>',
                            orderable: false
                        },
                        {
                            data: 'null',
                            className: "approve ",
                            defaultContent: '<i class="bi bi-check-circle-fill"></i>',
                            orderable: false
                        },
                        {
                            data: 'null',
                            className: "reject",
                            defaultContent: '<i class="bi bi-x-circle-fill"></i>',
                            orderable: false
                        }


                    ]

                });


            }
        })


    });
}



$("#receiptTable").on("click", "td.view", function (e) {

    var currentRow = $(this).closest("tr");
    var col5 = currentRow.find("td:eq(4)").text(); // get current row 5th TD

    

    //alert(col1 + " " + col2 + " " + col3 + " " + col4 + " " + col5 + " " + col6);

                        var filename = col5;
                        download(filename);


})

       function download(filename){

        var element = document.createElement('a');
        element.setAttribute('href','./adminreceipt/'+filename);
       element.setAttribute('download', filename);
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);

       }




  $("#receiptTable").on("click", "td.approve", function (e) {
    var currentRow = $(this).closest("tr");
    var col1 = currentRow.find("td:eq(0)").text(); // get current row 1st TD value


    $.ajax({
            url: "./sql_functions/receipts.functions.php",
            dataType: "script",
            data:
            {
                id: col1,
                typeOfFuntion: 'approve',

            },
            success: function (data) {

                if(data == 0){
                    Swal.fire({
                        icon: "success",
                        title: "Inquiry Approved",
                      });  

                      $('#receiptTable').DataTable().clear().destroy();
                      setPendingTable();

                }
                else{
                    Swal.fire({
                        icon: "error",
                        title: "Unable to Approve",
                      });  
                }
            }
        })
  })



  
  $("#receiptTable").on("click", "td.reject", function (e) {
    var currentRow = $(this).closest("tr");
    var col1 = currentRow.find("td:eq(0)").text(); // get current row 1st TD value


    $.ajax({
            url: "./sql_functions/receipts.functions.php",
            dataType: "script",
            data:
            {
                id: col1,
                typeOfFuntion: 'rejected'

            },
            success: function (data) {

                if(data == 0){
                    Swal.fire({
                        icon: "warning",
                        title: "Inquiry Rejected",
                      });  

                      $('#receiptTable').DataTable().clear().destroy();
                      setPendingTable();

                }
                else{
                    Swal.fire({
                        icon: "error",
                        title: "Unable to Reject",
                      });  
                }


            }
        })
  })
