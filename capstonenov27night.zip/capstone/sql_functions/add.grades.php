<?php
include '/xampp/htdocs/capstone/dbconnect.php';



$st_schoolid = str_replace("'", "''", htmlspecialchars($_GET['st_schoolid']));
$finalgrade = str_replace("'", "''", htmlspecialchars($_GET['grade']));
$sub_code = str_replace("'", "''", htmlspecialchars($_GET['subject_code']));


$sql_duplicate = "SELECT st_schoolid, subject_code FROM grades WHERE st_schoolid = '$st_schoolid' AND subject_code = '$sub_code'";

$result_row = mysqli_query($conn, $sql_duplicate);


if(mysqli_num_rows($result_row) == 0){

    $insert_grade = "INSERT INTO `grades`(`st_schoolid`, `subject_code`, `grade`) 
    VALUES ('$st_schoolid','$sub_code','$finalgrade')";

$res1 = mysqli_query($conn, $insert_grade);


if ($res1) {
echo 0;
} else {
echo 1;
}


}





?>
