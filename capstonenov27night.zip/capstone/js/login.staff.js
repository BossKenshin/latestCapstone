

$("#btn-login").click(function () {

    var user = document.getElementById("username").value;
    var pass = document.getElementById("pass").value;

        
    
    var format = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
    
        if(!format.test(user) && !format.test(pass)){
    $.ajax({
        url: "./sql_functions/login.staff.php",
        type: "GET",
        data: {
            user: user,
            pass: pass
        }
    })
        .done(function (data2) {
    
            let result = JSON.parse(data2);
            
            console.log(result);
    
            if (result.length != 0) {
                // alert("done saving data");

                if(result[0].type == "Registrar"){
               localStorage.setItem('admin_id',result[0].id);
               
               window.location.href = "./dashboard.php";

                }
                else if(result[0].type == "Vice"){
                   localStorage.setItem('vp_id',result[0].id);
                   window.location.href = "./vp.dashboard.php";
                }
                else if(result[0].type == "Department"){
                   localStorage.setItem('dept_id',result[0].id);
                   window.location.href = "./department.dashboard.php";
                }
                else{
                   localStorage.setItem('teacher_id',result[0].id);
               window.location.href = "./teacher.dashboard.php";
                }
    
               
    
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "Your login credential don't match an account to the system",
    
                })
            }
    
    
        });
    
    
    }
    
    else{
    
    
    
    }
    
    
    })
    
    