<?php
include '/xampp/htdocs/capstone/dbconnect.php';






$text = htmlspecialchars($_GET['concernText']);
$teacher = htmlspecialchars($_GET['te']);

// $teacherid = str_replace( "'" ,"''",htmlspecialchars($_GET['sem']));



$insertFile = "INSERT INTO `concern`(`textValue`, `teacher_name`, `student_name`) 
VALUES ('$text','$teacher')";

$res = mysqli_query($conn, $insertFile);

if($res){

echo 0;
}
else{
echo 1;
}



?>