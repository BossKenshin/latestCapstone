<?php

include '/xampp/htdocs/capstone/dbconnect.php';

$code = $_GET['sub_code'];
$sid = $_GET['st_id'];
$grade = $_GET['grade'];


$sql_fetch_completion = "UPDATE grades SET grade = '$grade' WHERE st_schoolid = '$sid' AND subject_code = '$code'";


$res = mysqli_query($conn,$sql_fetch_completion);

if ($res) {

    $cid = $_GET['cid'];
    $sql_delete = "DELETE FROM completion_grade WHERE cid = '$cid'";

    $res2 = mysqli_query($conn,$sql_delete);

    if($res){
        echo 0;
    }

}
else{
    echo 1;

}










?>