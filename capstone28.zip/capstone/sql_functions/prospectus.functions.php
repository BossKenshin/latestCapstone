<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$type = $_POST['typeOfFunction'];


if($type == 'add'){

    
$file_tmp = $_FILES['file']['tmp_name'];

$file_name =  $_FILES['file']['name'];
$pdfFileName = str_replace(" ", "", $file_name);

$course = str_replace( "'" ,"''",htmlspecialchars($_POST['cid']));



    $insert = "INSERT INTO prospectus (course_id, prosfilename) VALUES('$course','$pdfFileName')";

    $result = mysqli_query($conn, $insert);

    if($result){
        move_uploaded_file($file_tmp,"C:/xampp/htdocs/capstone/prospectusfiles/".$pdfFileName);
        echo 0;
    }
    else{
        echo 1;
    }

}
else{

    
$file_tmp = $_FILES['file']['tmp_name'];

$file_name =  $_FILES['file']['name'];
$pdfFileName = str_replace(" ", "", $file_name);

$course = str_replace( "'" ,"''",htmlspecialchars($_POST['cid']));

    $update = "UPDATE prospectus SET prosfilename ='$pdfFileName' WHERE course_id = '$course'";

    $result = mysqli_query($conn, $update);

    if($result){
        move_uploaded_file($file_tmp,"C:/xampp/htdocs/capstone/prospectusfiles/".$pdfFileName);
        echo 0;
    }
    else{
        echo 1;
    }

}



?>