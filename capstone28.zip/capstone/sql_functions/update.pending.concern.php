<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$id = $_GET['id'];
$val = $_GET['val'];


$update_data = "UPDATE concern SET concern.status = '$val' WHERE concern_id = '$id'";



$res = mysqli_query($conn,$update_data);

if($res){
echo 0;
}
else{
echo 1;
}




?>