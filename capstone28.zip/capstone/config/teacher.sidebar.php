<div class="container-fluid" style="min-height: 100vh; max-height: fit-content; padding-bottom: 10px;">

    <p class="h4 p-3 text-light text-center" id="demo">CRMC OGIS</p>

    <div class="list-group" style="font-size: 14px;">

        <p class="h6 text-light">TEACHER DASHBOARD</p>
        
        <hr>
        <br>
        <a type="button" class="list-group-item list-group-item-action sidebar-btn" href="teacher.dashboard.php"><i class="bi bi-person-fill"></i>List of Students</a>
        <a type="button" class="list-group-item list-group-item-action sidebar-btn" href="teacher.send.files.php"><i class="bi bi-diagram-3-fill"></i>Send Files</a>
        <a type="button" class="list-group-item list-group-item-action sidebar-btn" href="teacher.concerns.php"><i class="bi bi-people-fill"></i> Issues</a>
      
        <br>
        <hr>
        <br>
        <button type="button" class="list-group-item list-group-item-action sidebar-btn" id="btn-logout-teacher"><i class="bi bi-box-arrow-right"></i> Log Out</button>

    </div>



</div>