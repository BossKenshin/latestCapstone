$('#bond-wrapper').hide();

$('#btn-GWA').click(function(){

$('#modalForGWA').modal('show');

})

var section;

$('#create-GWA').click(function(){

  const vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
const vh = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);

if(vw > 1000){

    // $('#modalForGWA').modal('hide');
    var fullname = document.getElementById('yourname').value;
    var cl = document.getElementById('cl').value;
    var sy = document.getElementById('sy').value;
     section = document.getElementById('section').value;

    if(fullname != '' && cl != '' && sy != '' && section != ''){

        var sem_val = document.getElementById("semester").value;


        var sem;


        if( sem_val=='1st'){
            sem = "First Semester";
        }
        else if(sem_val=='2nd'){
            sem = "Second Semester";
        }
        else{
            sem = "Summer";
        }
       


        document.getElementById('schoolYear').innerHTML =  ", School Year "+ sy;
        document.getElementById('courseLevel').innerHTML =  cl;
        document.getElementById('st_name').innerHTML =  fullname;
        document.getElementById('id').innerHTML =  ssid;
        document.getElementById('sem').innerHTML =  sem;

        var date = new Date();
	        var current = date.getFullYear()+"/"+(date.getMonth()+1)+"/"+ date.getDate() +' '+ date.getHours()+":"+date.getMinutes()+":"+ date.getSeconds();
            document.getElementById('dt').innerHTML =  current;

        loadSelectedSubjects();




    }
    else{
        Swal.fire({
            icon: "error",
            title: "Something is missing",
            text: "Please fill out the form",
          });   
    }
  }
  else{
    Swal.fire({
      icon: "error",
      title: "Device not supported",
      text: "Please use a computer",
    });  
  }
})



function loadSelectedSubjects() {

    var year = document.getElementById("yearLevel").value;
    var sem = document.getElementById("semester").value;
    
  
    c//onsole.log(year + sem  + studentCourse);
  
    $(document).ready(function () {
      $.ajax({
        url: "./sql_functions/fetch.subject.student.php",
        data: {
          year: year,
          sem: sem,
          course: c
        },
        success: function (data) {
          var json = JSON.parse(data);
          // get template
          const template = document.querySelector("#template-gwa");
  
          //get the parent element
          const parent = document.querySelector("#gwaTable tbody");
  
          $("#gwaTable tbody").empty();
  
          for (let i = 0; i < json.length; i++) {
            //clone the template
            let clone = template.content.cloneNode(true);
  
            clone.querySelector("#code").innerHTML = json[i].subject_code;
            clone.querySelector("#desc").innerHTML = json[i].subject_name;
            clone.querySelector("#section").innerHTML = section;
            clone.querySelector("#units").innerHTML = json[i].units;
            clone.querySelector("#rating").innerHTML = "NG";
            clone.querySelector("#status").innerHTML = " ";
            clone.querySelector("#offcode").innerHTML = " ";

  
            //apppend
            parent.append(clone);
          }

         setGrades(ssid, year, sem,c);

        },
      });
    });
  }
    


  

function setGrades(student_sid, year, sem, c) {

    //console.log(student_sid + "  " + year + " " + sem + " " + studentCourse);

  $.ajax({
    url: "./sql_functions/fetch.grades.php",
    data: {
      id: student_sid,
      year: year,
      sem: sem,
      course: c
    },
    success: function (data) {
      var g = JSON.parse(data);

      console.log(g);

      var _row = document.querySelectorAll("#gwaTable tbody tr");
      var val = [];
      // alert(_row.length);

      for (let i = 0; i < _row.length; i++) {
        val.push(
          $("#gwaTable")
            .find("tbody tr:eq(" + i + ")")
            .find("td:eq(0)")
            .text()
        );
      }

      for (let j = 0; j < val.length; j++) {
        for (let k = 0; k < g.length; k++) {
          if (val[j] == g[k].subject_code) {
            $("#gwaTable")
              .find("tbody tr:eq(" + j + ")")
              .find("td:eq(4)")
              .text(g[k].grade);
          }
        }
      }


      var count = $('#gwaTable tbody tr').length; 

      if(count == g.length){
     var sum = parseFloat(0.00);
      for(let u= 0 ; u < g.length; u++) {

                   var rate = g[u].grade;

                   sum +=  parseFloat(rate);
      }

            document.getElementById('ave').innerHTML = sum;


      }
      else{
        document.getElementById('ave').innerHTML = "INCOMPLETE";

      }

      var rating = [] ;

      for (let i = 0; i < _row.length; i++) {
        rating.push(
          $("#gwaTable")
            .find("tbody tr:eq(" + i + ")")
            .find("td:eq(4)")
            .text()
        );
      }

      var ave;
      var course = document.getElementById('courseAbb').innerHTML;


      if(course == 'BSIT'){
          ave = parseFloat(5.0);
      }
      else{
        ave = parseFloat(3.5);
      }


      for(let m = 0; m < rating.length; m++){

          if(rating[m] == "NG"){
            $("#gwaTable")
            .find("tbody tr:eq(" + m + ")")
            .find("td:eq(5)")
            .text('Failed');
          }
          else if(rating[m] == "INC"){
            $("#gwaTable")
            .find("tbody tr:eq(" + m + ")")
            .find("td:eq(5)")
            .text('Failed');
          }
          else if(rating[m] <= ave){
            $("#gwaTable")
            .find("tbody tr:eq(" + m + ")")
            .find("td:eq(5)")
            .text('Passed');
          }
          else{
            $("#gwaTable")
            .find("tbody tr:eq(" + m + ")")
            .find("td:eq(5)")
            .text('Failed');
          }

      }

 

      



        $('#modalForGWA').modal('hide');


      var printContents = document.getElementById('bond-wrapper').innerHTML;
			var originalContents = document.body.innerHTML;

			document.body.innerHTML = printContents;

			window.print();

			document.body.innerHTML = originalContents;
            window.location.reload();

    },
  });
}
    
