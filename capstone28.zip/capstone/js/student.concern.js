var tid = localStorage.getItem('teacher_id');
var fullname = localStorage.getItem('teacher_name');; 



if(tid ==  null && fullname == null) {
  window.location.replace("./index.html");
}




setPendingTable();

function setPendingTable() {

    $(document).ready(function () {

        //var year = document.getElementById("StudentYear").value;
       


        $.ajax({
            url: "./sql_functions/fetch.pending.concerns.list.php",
            data:
            {
                fullname: fullname

            },
            success: function (data) {


                var pendingData = JSON.parse(data);

                console.log(pendingData);



                $('#studentConcernTable').DataTable({
                    data: pendingData,
                    columns: [
                        { data: 'concern_id' },
                         { data: 'student_name'},
                        { data: 'textValue' },
                        {
                            data: 'null',
                            className: "approve",
                            defaultContent: '<i class="bi bi-check-circle-fill"></i>',
                            orderable: false
                        },
                        {
                            data: 'null',
                            className: "reject",
                            defaultContent: '<i class="bi bi-x-circle-fill"></i>',
                            orderable: false
                        }


                    ],

                });


            }
        })


    });
}




  $("#studentConcernTable").on("click", "td.approve", function (e) {
    var currentRow = $(this).closest("tr");
    var col1 = currentRow.find("td:eq(0)").text(); // get current row 1st TD value


    $.ajax({
            url: "./sql_functions/update.pending.concern.php",
            dataType: "script",
            data:
            {
                id: col1,
                val: 'resolved'

            },
            success: function (data) {

                if(data == 0){
                    Swal.fire({
                        icon: "success",
                        title: "Concern Resolved",
                      });  

                      $('#studentConcernTable').DataTable().clear().destroy();
                      setPendingTable();

                }
                else{
                    Swal.fire({
                        icon: "error",
                        title: "Unable to Resolved",
                      });  
                }


            }
        })
  })




  
  $("#studentConcernTable").on("click", "td.reject", function (e) {
    var currentRow = $(this).closest("tr");
    var col1 = currentRow.find("td:eq(0)").text(); // get current row 1st TD value


    $.ajax({
            url: "./sql_functions/update.pending.concern.php",
            dataType: "script",
            data:
            {
                id: col1,
                val: 'rejected'

            },
            success: function (data) {

                if(data == 0){
                    Swal.fire({
                        icon: "success",
                        title: "Concern Resolved",
                      });  

                      $('#studentConcernTable').DataTable().clear().destroy();
                      setPendingTable();

                }
                else{
                    Swal.fire({
                        icon: "error",
                        title: "Unable to Reject",
                      });  
                }


            }
        })
  })


