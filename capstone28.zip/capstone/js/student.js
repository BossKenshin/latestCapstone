let ssid = localStorage.getItem('st_id');
let cid = localStorage.getItem('st_course');

var c;
var st_fullname;

if(ssid == null){

window.location.replace("./index.html");
}

loadInfo();



function loadInfo(){

    $(document).ready(function () {
        $.ajax({
          url: "./sql_functions/fetch.student.info.php",
          data: {
            st_id: ssid
          },
          success: function (data) {
            var json = JSON.parse(data);
            // get template
           
    
              //clone the template
    
              document.querySelector("#name").innerHTML = json[0].name;
              st_fullname = json[0].name;
              document.querySelector("#schoolid").innerHTML = 'School ID: ' + json[0].sid;
              document.querySelector("#courseAbb").innerHTML = 'Course: ' +json[0].course;
              c = json[0].course;
              document.querySelector("#department").innerHTML = 'Department: ' + json[0].department;
              document.querySelector("#year").innerHTML = 'Year: ' +json[0].year;


    
              //apppend
       
          },
        });
      });


      setTimeout(loadSubjects, 1000);
}




function loadSubjects() {

  var year = document.getElementById("yearLevel").value;
  var sem = document.getElementById("semester").value;
  

  c//onsole.log(year + sem  + studentCourse);

  $(document).ready(function () {
    $.ajax({
      url: "./sql_functions/fetch.subject.student.php",
      data: {
        year: year,
        sem: sem,
        course: c
      },
      success: function (data) {
        var json = JSON.parse(data);
        // get template
        const template = document.querySelector("#template");

        //get the parent element
        const parent = document.querySelector("#GradesTable tbody");

        $("#GradesTable tbody").empty();

        for (let i = 0; i < json.length; i++) {
          //clone the template
          let clone = template.content.cloneNode(true);

          clone.querySelector("#subCode").innerHTML = json[i].subject_code;
          clone.querySelector("#subject").innerHTML = json[i].subject_name;
          clone.querySelector("#Grade").innerHTML = " ";

          //apppend
          parent.append(clone);
        }
       getGrades(ssid, year, sem,c);
      },
    });
  });
}





function getGrades(student_sid, year, sem, c) {

    //console.log(student_sid + "  " + year + " " + sem + " " + studentCourse);

  $.ajax({
    url: "./sql_functions/fetch.grades.php",
    data: {
      id: student_sid,
      year: year,
      sem: sem,
      course: c
    },
    success: function (data) {
      var g = JSON.parse(data);

      console.log(g);

      var _row = document.querySelectorAll("tbody tr");
      var val = [];
      // alert(_row.length);

      for (let i = 0; i < _row.length; i++) {
        val.push(
          $("#GradesTable")
            .find("tbody tr:eq(" + i + ")")
            .find("td:eq(0)")
            .text()
        );
      }

      for (let j = 0; j < val.length; j++) {
        for (let k = 0; k < g.length; k++) {
          if (val[j] == g[k].subject_code) {
            $("#GradesTable")
              .find("tbody tr:eq(" + j + ")")
              .find("td:eq(2)")
              .text(g[k].grade);
          }
        }
      }

      // for(let j = 0; j < val.length; j++) {

      //     if(val[j] == "Purposive Communication"){
      //         $("#subjectTable").find('tbody tr:eq('+ j +')').find('td:eq(4)').text("new value")
      //     }

      // }
    },
  });
}

$( "#btn-send-receipt" ).click(function() {
  $('#modalSendReceipt').modal('show');
});

function setTeacherSearchBar(){
  

  $.ajax({
    url: "./sql_functions/fetch.all.teacher.list.php",
    success: function (data) {

      var result = JSON.parse(data);

       console.log(result);

      var element = document.getElementById("teacherList");

      $("#teacherList").empty();


      for (var i = 0; i < result.length; i++) {
        let op = document.createElement("option");

          op.value = result[i].fullname;
          op.textContent = result[i].fullname;
          element.append(op);
        
      }




    }
  });
}



function setTeacherConcernBar(){
  

  $.ajax({
    url: "./sql_functions/fetch.all.teacher.list.php",
    success: function (data) {

      var result = JSON.parse(data);

       console.log(result);

      var element = document.getElementById("teacherConcernList");

      $("#teacherConcernList").empty();


      for (var i = 0; i < result.length; i++) {
        let op = document.createElement("option");

          op.value = result[i].fullname;
          op.textContent = result[i].fullname;
          element.append(op);
        
      }




    }
  });
}

$('#btn-send-concern').click(function(){

  $('#modalForConcern').modal('show');


})


$('#send-Concern').click(function(){

  var concernText = document.getElementById('concernInput').value;
  var te = document.getElementById('tcname').value;
 
  if(concernText != '' && te != ''){

$.ajax({
  url: "./sql_functions/submit.concern.php",
  method: "GET",
  dataType: "script",
  data: {
    concernText : concernText,
    te : te,
    st: st_fullname

  },
  success: function (data) {

    if(data == 0){
      Swal.fire({
        icon: "success",
        title: "Concern Sent to " + te,
        text: "Please wait, it will be reviewed by the teacher",
      }); 
      
      $('#modalForConcern').modal('hide');

    }
    else{
      Swal.fire({
        icon: "error",
        title: "Something is missing",
        text: "Please resend if nothing is missing",
      });  
      
      $('#modalForConcern').modal('hide');

    }


  }
});

  }
  else{

    Swal.fire({
      icon: "error",
      title: "Something is missing",
      text: "Please fill out the form",
    });  

  }

})


  
$("#typeReceipt")
.change(function () {
$("#typeReceipt option:selected").each(function () {
  // state here what happens if the selected option is selected

  var type = $(this).val();


  


  //var elementDropdown = document.getElementById("chooseDept");
  if(type != "Completion" ){
    $('#hidden-row').hide();

  }
  else{

    $('#hidden-row').show();

  }


});
})
.change();


$('#sendReceipt').click(function (){

var typeR = document.getElementById('typeReceipt').value;

if(typeR == "Completion" ){

var sub = document.getElementById('completion-subject').value;

var teach = document.getElementById('tname').value;
var file_data = $('#filePic').prop('files')[0];    //Fetch the file


if(sub != "" && teach != "" && file_data){



var form_data = new FormData();



form_data.append("file",file_data);  
form_data.append('sub', sub);
form_data.append('teacher', teach);
form_data.append('st_id', ssid);

console.log(form_data);


$.ajax({
  url: "./sql_functions/submit.completion.receipt.php",
  method: "POST",
  dataType: "script",
  data: form_data,
  processData: false,
  contentType: false,
  success: function (data) {

    if(data == 0){
      Swal.fire({
        icon: "success",
        title: "Receipt Sent",
        text: "Please wait, it will be reviewed by the teacher",
      });   
    }
    else{
      Swal.fire({
        icon: "error",
        title: "Something is missing",
        text: "Please resend if nothing is wrong",
      });   
    }




  }
});

}
else{
  Swal.fire({
    icon: "error",
    title: "Something is missing",
    text: "Please fill out the form",
  });   
}
}
else{


  

var file_data = $('#filePic').prop('files')[0];    //Fetch the file
var len = document.getElementById("filePic").files.length;
var form_data = new FormData();

if(len != 0){

form_data.append("file",file_data);  
form_data.append('st_id', ssid);
form_data.append('typeR', typeR);


console.log(form_data);


$.ajax({
  url: "./sql_functions/submit.receipt.php",
  method: "POST",
  dataType: "script",
  data: form_data,
  processData: false,
  contentType: false,
  success: function (data) {

    if(data == 0){
      Swal.fire({
        icon: "success",
        title: "Receipt Sent",
        text: "Please wait, it will be reviewed by the admin",
      });   
    }
    else{
      Swal.fire({
        icon: "error",
        title: "Something is missing",
        text: "Please resend if nothing is wrong",
      });   
    }




  }
});}

else{
  Swal.fire({
    icon: "error",
    title: "Something is missing",
    text: "Please fill out the form",
  });   
}

}



})